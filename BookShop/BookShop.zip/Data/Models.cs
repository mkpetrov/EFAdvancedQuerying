﻿namespace BookShop.Data
{
    internal class Models
    {
    }
}