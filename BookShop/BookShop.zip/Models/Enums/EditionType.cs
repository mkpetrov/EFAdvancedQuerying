﻿namespace BookShop.Models.Enums
{
    public enum EditionType
    {
        Normal = 1,
        Promo = 2,
        Gold = 3
    }
}
