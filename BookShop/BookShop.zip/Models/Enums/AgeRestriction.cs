﻿namespace BookShop.Models.Enums
{
    public enum AgeRestriction
    {
        Minor = 1,
        Teen = 2,
        Adult = 3
    }
}
